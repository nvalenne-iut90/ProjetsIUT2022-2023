require("dotenv").config()
const port = process.env.PORT;
console.log(port);
const express = require("express")
const app = express();



app.get("/",(req,res)=>{
    console.log("Requete recue!!")
    console.log(req.query);
    let response = "";
    Object.keys(req.query).forEach((key,index)=>{
        console.log(`${key} : ${req.query[key]}`);
        response += `<br/> ${key} : ${req.query[key]}`
    })
    res.status(200).send(`<h1>Bonjour</h1>
                        <br/><h2>la reponse:</h2>
                        ${response}`);
});


app.listen(port,()=>{
    console.log(`Le serveur ecoute sur port ${port}`)
});
