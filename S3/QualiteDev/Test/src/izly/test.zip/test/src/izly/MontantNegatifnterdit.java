package izly;

public class MontantNegatifnterdit extends Exception{
}
