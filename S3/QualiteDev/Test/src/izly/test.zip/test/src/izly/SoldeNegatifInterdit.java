package izly;

public class SoldeNegatifInterdit extends Exception{
}
