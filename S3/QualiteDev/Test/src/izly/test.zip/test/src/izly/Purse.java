package izly;

public class Purse {
    private double solde = 0;
    private double plafond;
    public int dureeVieMax;
    private CodeSecret codeSecret;

    public Purse(double plafond, int dureeVieMax, CodeSecret secretCode) {
        this.plafond = plafond;
        this.dureeVieMax = dureeVieMax;
        this.codeSecret = secretCode;
    }

    public double getSolde() {
        return solde;
    }

    public void credite(double montant, String codePin) throws DepassementPlafondInterdit, MontantNegatifnterdit, DureeVieDepassee, CodeFauxExeption {
        if (dureeVieMax <= 0) throw new DureeVieDepassee();
        if (montant < 0) throw new MontantNegatifnterdit();
        if (montant+solde > plafond) throw new DepassementPlafondInterdit();
        if (!codeSecret.verifierCode(codePin)) throw new CodeFauxExeption();
        solde += montant;
        dureeVieMax--;
    }

    public void debite(double montant, String codePin) throws SoldeNegatifInterdit, MontantNegatifnterdit, DureeVieDepassee, CodeFauxExeption {
        if (dureeVieMax <= 0) throw new DureeVieDepassee();
        if (montant < 0) throw new MontantNegatifnterdit();
        if (montant > solde) throw new SoldeNegatifInterdit();
        if (!codeSecret.verifierCode(codePin)) throw new CodeFauxExeption();
        solde -= montant;
        dureeVieMax--;
    }
}
