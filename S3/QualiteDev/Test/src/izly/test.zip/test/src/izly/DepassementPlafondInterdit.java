package izly;

public class DepassementPlafondInterdit extends Exception{
}
