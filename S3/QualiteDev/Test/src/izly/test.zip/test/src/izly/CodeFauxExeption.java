package izly;

public class CodeFauxExeption extends Exception{
}
