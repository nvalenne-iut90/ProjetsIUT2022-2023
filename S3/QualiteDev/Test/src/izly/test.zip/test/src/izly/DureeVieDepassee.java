package izly;

public class DureeVieDepassee extends Exception{
}
