package izly;

import java.util.Random;

public class MyRandom extends Random {
}
